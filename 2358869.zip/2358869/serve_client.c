#include <pthread.h>

pthread_mutex_t mutex1 = PTHRED_MUTEX_INITIALIZER;

void *downtime()
{
    Node *balance_root;
    Node *root;

    // Downtime 1
    sleep(2);
    pthread_mutex_lock(&mutex1);
    balance_root = balanceTree(root);
    subtreeFree(root);
    root = balance_root;
    pthread_mutex_unlock(&mutex1);

    // Downtime 2
    sleep(2);
    pthread_mutex_lock(&mutex1);
    balance_root = balanceTree(root);
    subtreeFree(root);
    root = balance_root;
    pthread_mutex_unlock(&mutex1);

    // Downtime 3
    sleep(2);
    pthread_mutex_lock(&mutex1);
    balance_root = balanceTree(root);
    subtreeFree(root);
    root = balance_root;
    pthread_mutex_unlock(&mutex1);
}

void *ServeClient(char *client)
{
    char line(100);
    FILE *files;
    fp = fopen(client, "r");
    int value;
    int sum;

    if (files == NULL)
    {
        printf("File did not open. %s", client);
    }

    while (fscanf(fp, "%s, %d", line, &value) != EOF)
    {
        if (strcmp(line, "addNode") == 0)
        {
            pthread_mutex_lock(&mutex1);
            root = addNode(root, value);
            printf("[%s]%s %d\n", client, line, value);
            pthread_mutex_unlock(&mutex1);
        }
        else if (strcmp(line, "removeNode") == 0)
        {
            pthread_mutex_lock(&mutex1);
            root = removeNode(root, value);
            printf("[%s]%s %d\n", client, line, value);
            pthread_mutex_unlock(&mutex1);
        }
        else if (strcmp(line, "countNodes") == 0)
        {
            pthread_mutex_lock(&mutex1);
            sum = countNodes(root);
            printf("[%s]%s %d\n", client, line, sum);
            pthread_mutex_unlock(&mutex1);
        }
        else if (strcmp(line, "avgSubtree") == 0)
        {
            pthread_mutex_lock(&mutex1);
            sum = avgSubTree(root);
            printf("[%s]%s %d\n", client, line, sum);
            pthread_mutex_unlock(&mutex1);
        }

        fclose(files);
        return NULL;
    }
}
